import Trash.NewGameFrame;

import java.time.ZonedDateTime;
import java.time.temporal.ChronoUnit;
import java.util.HashMap;

public class Main {
    public static void main(String[] args) {
        GameHistoryFrame.addData("leble");
        GameHistoryFrame.addData("kalkal");
        GameHistoryFrame.addData("opopop");GameHistoryFrame.addData("leble");
        GameHistoryFrame.addData("kalkal");
        GameHistoryFrame.addData("opopop");GameHistoryFrame.addData("leble");
        GameHistoryFrame.addData("kalkal");
        GameHistoryFrame.addData("opopop");GameHistoryFrame.addData("leble");
        GameHistoryFrame.addData("kalkal");
        GameHistoryFrame.addData("opopop");
        StartMenu startMenu = new StartMenu();
        //StartMenu startMenu = new StartMenu();
    }
}