import javax.swing.*;

public class GameFrame extends JFrame{
    GameFrame(String myPlayer,String otherPlayer,boolean timeLimitedMode,int limitTime,boolean goalLimitedMode,int limitGoal,boolean twoMarginMode){
        GamePanel gamePanel = new GamePanel(myPlayer,otherPlayer,timeLimitedMode,limitTime,goalLimitedMode,limitGoal,twoMarginMode);
        this.add(gamePanel);
        this.pack();
        this.setResizable(false);
        this.setVisible(true);
        this.setTitle("AirHockey+");
        this.addKeyListener(gamePanel);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
}
