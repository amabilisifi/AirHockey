import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

public class GameHistoryFrame extends JFrame implements ActionListener {
    public static ArrayList<String> data = new ArrayList<>();
    JButton backButton = new JButton();
    GameHistoryFrame(){
        backButton.setText("back");
        backButton.setSize(80,40);
        backButton.setVisible(true);
        backButton.setOpaque(true);
        backButton.addActionListener(this);
        int n = data.size();

        for (int i = 0; i < n; i++) {
            this.add(new JButton(data.get(i)));
        }
        this.setLayout(new GridLayout(n+1,1));
        this.setSize(800,600);
        this.setVisible(true);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.add(backButton);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource()==backButton){
            this.dispose();
            StartMenu newStartMenu = new StartMenu();
        }
    }
    public static void addData(String input){
        data.add(input);
    }
}
