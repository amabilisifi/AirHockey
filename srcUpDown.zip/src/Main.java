import Trash.NewGameFrame;

import java.time.ZonedDateTime;
import java.time.temporal.ChronoUnit;
import java.util.HashMap;

public class Main {
    public static void main(String[] args) {
        StartMenu startMenu = new StartMenu();
    }
}